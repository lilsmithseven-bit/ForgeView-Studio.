# ForgeView Studio — Windows installer project

This project packages the offline photo editor as a Windows desktop application and builds a **Setup.exe installer**. The installer is configured to let the user choose an installation folder and create Start Menu and desktop shortcuts.

## Low-vision features included
- Larger interface text controls (A− / A+)
- High-contrast theme
- Yellow-on-black theme
- Reset visibility settings
- Keyboard-focus outlines and accessible labels
- Windows menu zoom controls and full-screen mode

## Build the installer on Windows
1. Install Node.js LTS from https://nodejs.org/
2. Extract this project folder.
3. Open PowerShell in the extracted folder.
4. Run:

   ```powershell
   npm install
   npm run dist
   ```

5. Open the `dist` folder. It will contain **ForgeView Studio Setup 1.0.0.exe** (the exact filename may vary slightly).

## Build using GitHub Actions (no local Windows setup needed)
1. Create a new GitHub repository and upload the contents of this project folder.
2. Open the repository's **Actions** tab.
3. Select **Build ForgeView Studio Setup.exe**.
4. Press **Run workflow** and wait for the Windows job to finish.
5. Open the completed workflow run and download the **ForgeView-Studio-Setup** artifact. It contains the Setup.exe installer.

The workflow is also triggered when you push a version tag beginning with `v`.

## Important
This ZIP contains the project source and an automated Windows build workflow; it does **not** contain a compiled `.exe`. A Windows build runner must execute the workflow to create the installer. I cannot access your GitHub account or start a build in a repository you have not connected.

## Run without packaging
Run `npm install` and then `npm start`.

Photo editing runs locally in the app; this project does not upload photos.
