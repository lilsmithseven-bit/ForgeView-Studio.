'use strict';
// Intentionally no Node APIs are exposed to the editor page.
