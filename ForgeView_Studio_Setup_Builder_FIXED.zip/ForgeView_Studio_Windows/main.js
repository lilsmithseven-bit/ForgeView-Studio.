const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 760,
    minHeight: 620,
    backgroundColor: '#10141c',
    autoHideMenuBar: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  win.loadFile(path.join(__dirname, 'app', 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://') || url.startsWith('http://')) shell.openExternal(url);
    return { action: 'deny' };
  });

  const menu = Menu.buildFromTemplate([
    { label: 'File', submenu: [
      { label: 'Reload editor', accelerator: 'Ctrl+R', click: () => win.reload() },
      { type: 'separator' },
      { role: 'quit', label: 'Exit' }
    ]},
    { label: 'View', submenu: [
      { role: 'zoomIn', label: 'Zoom in' },
      { role: 'zoomOut', label: 'Zoom out' },
      { role: 'resetZoom', label: 'Reset zoom' },
      { type: 'separator' },
      { role: 'togglefullscreen', label: 'Full screen' },
      { role: 'toggleDevTools', label: 'Developer tools' }
    ]},
    { label: 'Help', submenu: [
      { label: 'About ForgeView Studio', click: () => {
        require('electron').dialog.showMessageBox(win, {
          type: 'info',
          title: 'About ForgeView Studio',
          message: 'ForgeView Studio',
          detail: 'Offline photo editor with low-vision accessibility controls.'
        });
      }}
    ]}
  ]);
  Menu.setApplicationMenu(menu);
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
